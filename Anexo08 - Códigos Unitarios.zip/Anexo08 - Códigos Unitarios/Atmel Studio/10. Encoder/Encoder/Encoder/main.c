/*
 * Encoder.c
 *
 * Created: 6/11/2023 1:12:02 a. m.
 * Author : danie
 */ 

#include <avr/io.h>
#include <stdbool.h>// Booleanos

#define LedR 0x02
#define LedV 0x20
#define LedY 0x08
#define LedB 0x04

#define Encoder1 0x04
#define Encoder2 0x08
#define Encoder3 0x08
#define Encoder4 0x10

//Variables de estado de seguidores
bool enc1 = 1;
bool enc2 = 1;
bool enc3 = 1;
bool enc4 = 1;

int main(void)
{
    DDRC |= LedR; //Led Rojo como salida
	PORTC &= ~(LedR); //Inicia apagado
	DDRC |= LedV; //Led Verde como salida
	PORTC &= ~(LedV); //Inicia apagado
	DDRC |= LedY; //Led Amarillo como salida
	PORTC &= ~(LedY); //Inicia apagado
	DDRC |= LedB; //Led Azul como salida
	PORTC &= ~(LedB); //Inicia apagado
	
	DDRD &= ~(Encoder1); //Encoder como entrada
	DDRD &= ~(Encoder2); //Encoder como entrada
	DDRK &= ~(Encoder3); //Encoder como entrada
	DDRK &= ~(Encoder4); //Encoder como entrada
	
    while (1) 
    {
		//Lectura de encoder
		enc1 = (PIND & Encoder1);
		enc2 = (PIND & Encoder2);
		enc3 = (PINK & Encoder3);
		enc3 = (PINK & Encoder4);
		
		if (enc1==0){
			DDRC |= LedV; //Enciende led Verde
			} else {
			PORTC &= ~(LedV); //Apaga led Verde
		}
		
		if (enc2==0){
			DDRC |= LedR; //Enciende led Rojo
			} else {
			PORTC &= ~(LedR); //Apaga led Rojo
		}
		
		if (enc3==0){
			DDRC |= LedY; //Enciende led Amarillo
			} else {
			PORTC &= ~(LedY); //Apaga led Amarillo
		}
		
		if (enc4==0){
			DDRC |= LedB; //Enciende led Azul
			} else {
			PORTC &= ~(LedB); //Apaga led Azul
		}
    }
}

