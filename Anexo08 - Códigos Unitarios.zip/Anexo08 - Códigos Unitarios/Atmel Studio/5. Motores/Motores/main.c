/*
 * Motores.c
 *
 * Created: 15/10/2023 6:20:53 p. m.
 * Author : danie
 */ 

#define F_CPU 16000000

#include <avr/io.h>
#include "PWM/PWM.h"
#include <util/delay.h>	

#define RELEASE 0x00
#define FORWARD 0x96
#define BACKWARD 0x69
#define LEFT 0x55
#define RIGTH 0xAA
#define LEFT_FORWARD 0x14
#define RIGTH_BACKWARD 0x28
#define RIGTH_FORWARD 0x82
#define LEFT_BACKWARD 0x41
#define ROTATE_RIGTH 0x99
#define ROTATE_LEFT 0x66

int main(void)
{
	DDRF = 0xFF; //Seleccionar Motores como salida
	DDRB |= 0x20; // Salida CM1
	DDRH |= 0x38; //Salida CM2, CM3 y CM4
	PORTF = 0x00; //Inicializa motores apagados
	
	PWM_init(11); //Inicializa CM1
	PWM_init(8); //Inicializa CM2
	PWM_init(6); //Inicializa CM3
	PWM_init(7); //Inicializa CM4
	
	//Colocar en velocidad maxima
	set_PWM(11, 255, 0); 
	set_PWM(8, 255, 0);
	set_PWM(6, 255, 0);
	set_PWM(7, 255, 0);
	
    while (1) 
    {
		//Adelante
		PORTF = FORWARD;
		_delay_ms(2000);
		
		//Atras
		PORTF = BACKWARD;
		_delay_ms(2000);
		
		//Izquierda
		PORTF = LEFT;
		_delay_ms(2000);
		
		//Derecha
		PORTF = RIGTH;
		_delay_ms(2000);
		
		//Adelante - Izquierda
		PORTF = LEFT_FORWARD;
		_delay_ms(2000);
		
		//Adelante - Derecha
		PORTF = RIGTH_FORWARD;
		_delay_ms(2000);
		
		//Atras - Izquierda
		PORTF = LEFT_BACKWARD;
		_delay_ms(2000);
		
		//Atras - Derecha
		PORTF = RIGTH_BACKWARD;
		_delay_ms(2000);
		
		//Rotar a Derecha
		PORTF = ROTATE_RIGTH;
		_delay_ms(2000);
		
		//Rotar a Izquierda
		PORTF = ROTATE_LEFT;
		_delay_ms(2000);
		
		//Detener
		PORTF = RELEASE;
		_delay_ms(2000);
		
    }
}

