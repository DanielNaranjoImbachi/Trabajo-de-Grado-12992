﻿/*
 * PWM.c
 *
 * Created: 6/10/2023 7:06:08 p. m.
 *  Author: danie
 */ 

#include "PWM.h"

void PWM_init(uint8_t pin)
{
	switch (pin)
	{
		case 2:
		case 3:
		case 5:
		//--##### Ajusta el modo FAST PWM ## Para timer 3 ajustar bits #####--
		//Para Timer 3 8-Bits:
		TCCR3B |= 0x80; //Registro WGMn2
		TCCR3A |= 0x01; //Registros WGMn1 y WGMn0
		//Para Timer 3 9-Bits:
		//TCCR3B |= 0x80; //Registro WGMn2
		//TCCR3A |= 0x02; //Registros WGMn1 y WGMn0
		//Para Timer 3 10-Bits:
		//TCCR3B |= 0x80; //Registro WGMn2
		//TCCR3A |= 0x03; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 3 #####--
		//TCCR3B |= 0x01; //Preescaler de 1
		//TCCR3B |= 0x02; //Preescaler de 8
		//TCCR3B |= 0x03; //Preescaler de 64
		//TCCR3B |= 0x4; //Preescaler de 256
		TCCR3B |= 0x05; //Preescaler de 1024
		break;
		
		case 4:
		case 13:
		//--##### Ajusta el modo FAST PWM #####--
		TCCR0B &= ~(0x08); //Registro WGM02
		TCCR0A |= 0x03; //Registros WGM01 y WGM00
		
		//--##### Selecciona el prescalador Timer 0 #####--
		//TCCR0B |= 0x01; //Preescaler de 1
		//TCCR0B |= 0x02; //Preescaler de 8
		//TCCR0B |= 0x03; //Preescaler de 64
		//TCCR0B |= 0x4; //Preescaler de 256
		TCCR0B |= 0x05; //Preescaler de 1024
		break;
		
		case 6:
		case 7:
		case 8:
		//--##### Ajusta el modo FAST PWM ## Para timer 4 ajustar bits #####--
		//Para Timer 4 8-Bits:
		TCCR4B |= 0x80; //Registro WGMn2
		TCCR4A |= 0x01; //Registros WGMn1 y WGMn0
		//Para Timer 4 9-Bits:
		//TCCR4B |= 0x80; //Registro WGMn2
		//TCCR4A |= 0x02; //Registros WGMn1 y WGMn0
		//Para Timer 4 10-Bits:
		//TCCR4B |= 0x80; //Registro WGMn2
		//TCCR4A |= 0x03; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 4 #####--
		//TCCR4B |= 0x01; //Preescaler de 1
		//TCCR4B |= 0x02; //Preescaler de 8
		//TCCR4B |= 0x03; //Preescaler de 64
		//TCCR4B |= 0x4; //Preescaler de 256
		TCCR4B |= 0x05; //Preescaler de 1024
		break;
		
		case 9:
		case 10:
		//--##### Ajusta el modo FAST PWM #####--
		TCCR2B &= ~(0x08); //Registro WGM22
		TCCR2A |= 0x03; //Registros WGM21 y WGM20
		
		//---##### Selecciona el prescalador Timer 2 #####--
		//TCCR2B |= 0x01; //Preescaler de 1
		//TCCR2B |= 0x02; //Preescaler de 8
		//TCCR2B |= 0x03; //Preescaler de 32
		//TCCR2B |= 0x4; //Preescaler de 64
		//TCCR2B |= 0x05; //Preescaler de 128
		//TCCR2B |= 0x06; //Preescaler de 256
		TCCR2B |= 0x07; //Preescaler de 1024
		break;
		
		case 11:
		case 12:
		//--##### Ajusta el modo FAST PWM ## Para timer 1 ajustar bits #####--
		//Para Timer 1 8-Bits:
		TCCR1B |= 0x80; //Registro WGMn2
		TCCR1A |= 0x01; //Registros WGMn1 y WGMn0
		//Para Timer 1 9-Bits:
		//TCCR1B |= 0x80; //Registro WGMn2
		//TCCR1A |= 0x02; //Registros WGMn1 y WGMn0
		//Para Timer 1 10-Bits:
		//TCCR1B |= 0x80; //Registro WGMn2
		//TCCR1A |= 0x03; //Registros WGMn1 y WGMn0 
		
		//---##### Selecciona el prescalador Timer 1 #####--
		//TCCR1B |= 0x01; //Preescaler de 1
		//TCCR1B |= 0x02; //Preescaler de 8
		//TCCR1B |= 0x03; //Preescaler de 64
		//TCCR1B |= 0x4; //Preescaler de 256
		TCCR1B |= 0x05; //Preescaler de 1024
		break;
		
		case 44:
		case 45:
		case 46:
		//--##### Ajusta el modo FAST PWM ## Para timer 5 ajustar bits #####--
		//Para Timer 5 8-Bits:
		TCCR5B |= 0x80; //Registro WGMn2
		TCCR5A |= 0x01; //Registros WGMn1 y WGMn0
		//Para Timer 5 9-Bits:
		//TCCR5B |= 0x80; //Registro WGMn2
		//TCCR5A |= 0x02; //Registros WGMn1 y WGMn0
		//Para Timer 5 10-Bits:
		//TCCR5B |= 0x80; //Registro WGMn2
		//TCCR5A |= 0x03; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 5 #####--
		//TCCR5B |= 0x01; //Preescaler de 1
		//TCCR5B |= 0x02; //Preescaler de 8
		//TCCR5B |= 0x03; //Preescaler de 64
		//TCCR5B |= 0x4; //Preescaler de 256
		TCCR5B |= 0x05; //Preescaler de 1024
		break;
		
		default:
			
		break;
		
	}
	
}

void set_PWM(uint8_t pin, uint8_t pwm, bool modo)
{
	switch (pin)
	{
		case 2:
		if(modo == 1)
		{
			TCCR3A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR3A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR3B = pwm;
		break;
		
		case 3:
		if(modo == 1)
		{
			TCCR3A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR3A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR3C = pwm;
		break;
		
		case 4:
		if(modo == 1)
		{
			TCCR0A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR0A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR0B = pwm;
		break;
		
		case 5:
		if(modo == 1)
		{
			TCCR3A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR3A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR3A = pwm;
		break;
		
		case 6:
		if(modo == 1)
		{
			TCCR4A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR4A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR4A = pwm;
		break;
		
		case 7:
		if(modo == 1)
		{
			TCCR4A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR4A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR4B = pwm;
		break;
		
		case 8:
		if(modo == 1)
		{
			TCCR4A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR4A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR4C = pwm;
		break;
		
		case 9:
		if(modo == 1)
		{
			TCCR2A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR2A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR2B = pwm;
		break;
		
		case 10:
		if(modo == 1)
		{
			TCCR2A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR2A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR2A = pwm;
		break;
		
		case 11:
		if(modo == 1)
		{
			TCCR1A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR1A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR1A = pwm;
		break;
		
		case 12:
		if(modo == 1)
		{
			TCCR1A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR1A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR1B = pwm;
		break;
		
		case 13:
		if(modo == 1)
		{
			TCCR0A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR0A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR0A = pwm;
		break;
		
		case 44:
		if(modo == 1)
		{
			TCCR5A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR5A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR5C = pwm;
		break;
		
		case 45:
		if(modo == 1)
		{
			TCCR5A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR5A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR5B = pwm;
		break;
		
		case 46:
		if(modo == 1)
		{
			TCCR5A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR5A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR5A = pwm;
		break;
		
		default:
		
		break;
	}
}