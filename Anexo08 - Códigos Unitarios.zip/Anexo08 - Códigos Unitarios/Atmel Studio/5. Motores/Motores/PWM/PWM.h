﻿/*
 * PWM.h
 *
 * Created: 6/10/2023 7:04:05 p. m.
 *  Author: danie
 */ 

#include <avr/io.h>
#include <stdbool.h>// Booleanos

#ifndef PWM_H_
#define PWM_H_

void PWM_init(uint8_t pin);
void set_PWM(uint8_t pin, uint8_t dc, bool modo);

#endif /* PWM_H_ */