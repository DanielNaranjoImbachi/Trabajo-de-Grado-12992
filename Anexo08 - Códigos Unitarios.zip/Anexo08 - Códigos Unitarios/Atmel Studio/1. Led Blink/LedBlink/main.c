/*
 * LedBlink.c
 *
 * Created: 4/10/2023 2:38:15 p. m.
 * Author : danie
 */ 

#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRC |= 0x20; // El pin 5 del puerto C se declara como salida // Led del pin32 del Arduino
	PORTC &= ~(0x20); // Pone en 0 el pin 5 del PORTC. No modifica los demas pines del puerto.
	DDRC |= 0x10; // El pin 4 del puerto C se declara como salida // Led del pin33 del Arduino
	PORTC &= ~(0x10); // Pone en 0 el pin 4 del PORTC. No modifica los demas pines del puerto.
	DDRC |= 0x08; // El pin 3 del puerto C se declara como salida // Led del pin34 del Arduino
	PORTC &= ~(0x08); // Pone en 0 el pin 3 del PORTC. No modifica los demas pines del puerto.
	DDRC |= 0x04; // El pin 2 del puerto C se declara como salida // Led del pin35 del Arduino
	PORTC &= ~(0x04); // Pone en 0 el pin 2 del PORTC. No modifica los demas pines del puerto.
	DDRC |= 0x02; // El pin 1 del puerto C se declara como salida // Led del pin36 del Arduino
	PORTC &= ~(0x02); // Pone en 0 el pin 1 del PORTC. No modifica los demas pines del puerto.
	
	while (1)
	{
		PORTC |= 0x20; // se prende Led del pin 32
		_delay_ms(2000);
		PORTC &= ~(0x20); // se apaga el Led del pin 32
		_delay_ms(500);
		PORTC |= 0x10; // se prende Led del pin 33
		_delay_ms(2000);
		PORTC &= ~(0x10); // se apaga el Led del pin 33
		_delay_ms(500);
		PORTC |= 0x08; // se prende Led del pin 34
		_delay_ms(2000);
		PORTC &= ~(0x08); // se apaga el Led del pin 34
		_delay_ms(500);
		PORTC |= 0x04; // se prende Led del pin 35
		_delay_ms(2000);
		PORTC &= ~(0x04); // se apaga el Led del pin 35
		_delay_ms(500);
		PORTC |= 0x02; // se prende Led del pin 36
		_delay_ms(2000);
		PORTC &= ~(0x02); // se apaga el Led del pin 36
		_delay_ms(500);
	}
}

