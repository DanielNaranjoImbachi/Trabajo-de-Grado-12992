/*
 * puebaInt.c
 *
 * Created: 12/10/2023 7:07:41 a. m.
 * Author : danie
 */ 
#define F_CPU 16000000

#include <avr/io.h>
#include <avr/interrupt.h>
#include "UART/UART.h"
#include <util/delay.h>
#include <stdlib.h>

//Variables
uint16_t pulso = 0; //Valor del timer
int i = 0;
uint16_t almacena = 0; //valor del pulso en cm
char buffer [sizeof(unsigned int)*8+1];

int main(void)
{
	DDRK &= ~(0x80); //Echo como entrada
	DDRL |= 0x02; //Triguer como salida
	PORTL &= ~(0x02); //Inicia en 0
	PCICR |= 0x04; // Se activa la interrupcion en cualquier cambio logico de PCINT 0 a 7
	PCMSK2 |= 0x80; // Enable de la interrupcion PCINT23
	
	sei();
	
	UART_init();

    while (1) 
    {
		PORTL |= 0x02;
		_delay_us(10);
		PORTL &= ~(0x02);
		
		almacena = pulso;
		utoa(almacena, buffer, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("El valor es= ");
		UART_write_txt(buffer);
		UART_write_txt("cm \n\r");
    }
}

ISR(PCINT2_vect){
	//Configura el timer 5 en modo normal
	TCCR5A &= ~(0x03);
	TCCR5B &= ~(0x18);
	if(i==0){
		TCNT5 = 0x0000; // Reset al contador para iniciar el incremento
		//Seleccion del prescaler
		TCCR5B |= 0x05; //Prescaler de 1024
		i=1;
	}
	else{
		TCCR5B = 0;
		pulso=TCNT5; //Almacena el tiempo transcurrido por el timer
		TCNT5=0; //Se hace reset para no acumular valores
		i=0;
	}
}

