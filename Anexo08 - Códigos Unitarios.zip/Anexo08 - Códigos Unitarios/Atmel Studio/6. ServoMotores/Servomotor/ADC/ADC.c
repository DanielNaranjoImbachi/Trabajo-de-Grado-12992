﻿/*
 * ADC.c
 *
 * Created: 5/10/2023 6:49:09 p. m.
 *  Author: danie
 */ 

#include "ADC.h"

void ConfigurarADC()
{
	ADCSRA = 0x00; //Reset al registro
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	ADCSRA |= ((1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0)); // Preescaler = 128
	ADCSRA |= (1 << ADIF); //Limpiar bandera de conversión
	ADCSRA |= (1 << ADEN); //Encender el ADC
	ADCSRA |= (1 << ADSC); //Hacer la primera conversion de 25 ciclos
}

uint16_t leerADC(uint8_t canal, bool sup)
{
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	if (sup==1)
	{
		ADCSRB |= 0x08;
	}else{
		ADCSRB &= ~(0x08);
	}
	ADMUX |= canal; //Usa la mascara para seleccionar el puerto de lectura
	ADCSRA |= (1 << ADSC); //Inicia la conversion
	while((ADCSRA) & (1 << ADSC));  //Si ya finalizo la conversion
	return(ADC); // Guardar 
}