﻿/*
 * servo.h
 *
 * Created: 9/10/2023 11:43:45 p. m.
 *  Author: danie
 */ 

#include <avr/io.h>
#include <stdbool.h>// Booleanos

#ifndef SERVO_H_
#define SERVO_H_

void SERVO_init(uint8_t pin);
void set_SERVO(uint8_t pin, uint16_t dc, bool modo);

#endif /* SERVO_H_ */