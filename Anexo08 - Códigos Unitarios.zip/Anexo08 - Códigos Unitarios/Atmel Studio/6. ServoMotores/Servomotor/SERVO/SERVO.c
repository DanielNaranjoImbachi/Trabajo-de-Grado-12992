﻿/*
 * SERVO.c
 *
 * Created: 9/10/2023 11:45:09 p. m.
 *  Author: danie
 */ 

#include "SERVO.h"

void SERVO_init(uint8_t pin)
{
	switch (pin)
	{
		case 2:
		case 3:
		case 5:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR3B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR3A |= 0x02; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 3 #####--
		//TCCR3B |= 0x01; //Preescaler de 1
		//TCCR3B |= 0x02; //Preescaler de 8
		TCCR3B |= 0x03; //Preescaler de 64
		//TCCR3B |= 0x4; //Preescaler de 256
		//TCCR3B |= 0x05; //Preescaler de 1024
		ICR3 = 4999; //Para usar los servos com prescaler de 64
		break;
		
		case 6:
		case 7:
		case 8:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR4B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR4A |= 0x02; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 4 #####--
		//TCCR4B |= 0x01; //Preescaler de 1
		//TCCR4B |= 0x02; //Preescaler de 8
		TCCR4B |= 0x03; //Preescaler de 64
		//TCCR4B |= 0x4; //Preescaler de 256
		//TCCR4B |= 0x05; //Preescaler de 1024
		ICR4 = 4999; //Para usar los servos com prescaler de 64
		break;
		
		case 11:
		case 12:
		case 13:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR1B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR1A |= 0x02; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 1 #####--
		//TCCR1B |= 0x01; //Preescaler de 1
		//TCCR1B |= 0x02; //Preescaler de 8
		TCCR1B |= 0x03; //Preescaler de 64
		//TCCR1B |= 0x4; //Preescaler de 256
		//TCCR1B |= 0x05; //Preescaler de 1024
		ICR1 = 4999; //Para usar los servos com prescaler de 64
		break;
		
		case 44:
		case 45:
		case 46:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR5B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR5A |= 0x02; //Registros WGMn1 y WGMn0
		
		//---##### Selecciona el prescalador Timer 5 #####--
		//TCCR5B |= 0x01; //Preescaler de 1
		//TCCR5B |= 0x02; //Preescaler de 8
		TCCR5B |= 0x03; //Preescaler de 64
		//TCCR5B |= 0x4; //Preescaler de 256
		//TCCR5B |= 0x05; //Preescaler de 1024
		ICR5 = 4999; //Para usar los servos com prescaler de 64
		break;
		
		default:
		
		break;
		
	}
	
}

void set_SERVO(uint8_t pin, uint16_t pwm, bool modo)
{
	switch (pin)
	{
		case 2:
		if(modo == 1)
		{
			TCCR3A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR3A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR3B = pwm;
		break;
		
		case 3:
		if(modo == 1)
		{
			TCCR3A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR3A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR3C = pwm;
		break;
		
		case 5:
		if(modo == 1)
		{
			TCCR3A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR3A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR3A = pwm;
		break;
		
		case 6:
		if(modo == 1)
		{
			TCCR4A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR4A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR4A = pwm;
		break;
		
		case 7:
		if(modo == 1)
		{
			TCCR4A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR4A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR4B = pwm;
		break;
		
		case 8:
		if(modo == 1)
		{
			TCCR4A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR4A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR4C = pwm;
		break;
		
		case 11:
		if(modo == 1)
		{
			TCCR1A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR1A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR1A = pwm;
		break;
		
		case 12:
		if(modo == 1)
		{
			TCCR1A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR1A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR1B = pwm;
		break;
		
		case 13:
		if(modo == 1)
		{
			TCCR1A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR1A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR1C = pwm;
		break;
		
		case 44:
		if(modo == 1)
		{
			TCCR5A |= 0x0C; //Modo invertido PWM C
		}
		else {
			TCCR5A |= 0x08; //Modo no invertido PWM C
		}
		//Selecciona los ciclos de trabajo
		OCR5C = pwm;
		break;
		
		case 45:
		if(modo == 1)
		{
			TCCR5A |= 0x30; //Modo invertido PWM B
		}
		else {
			TCCR5A |= 0x20; //Modo no invertido PWM B
		}
		//Selecciona los ciclos de trabajo
		OCR5B = pwm;
		break;
		
		case 46:
		if(modo == 1)
		{
			TCCR5A |= 0xC0; //Modo invertido PWM A
		}
		else {
			TCCR5A |= 0x80; //Modo no invertido PWM A
		}
		//Selecciona los ciclos de trabajo
		OCR5A = pwm;
		break;
		
		default:
		
		break;
	}
}