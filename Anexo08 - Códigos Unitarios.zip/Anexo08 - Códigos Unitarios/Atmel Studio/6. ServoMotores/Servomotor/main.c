/*
 * Servomotor.c
 *
 * Created: 9/10/2023 6:05:17 p. m.
 * Author : danie
 */ 

#define F_CPU 16000000

#include <stdbool.h>// Booleanos
#include "SERVO/SERVO.h"
#include "ADC/ADC.h"
#include <util/delay.h>
#include "UART/UART.h"
#include <stdlib.h>

//Variables
uint16_t valorPot = 0;
uint16_t valor = 0;
uint16_t servo = 0;
uint16_t i;
char buffer [sizeof(unsigned int)*8+1];

int main(void)
{
	//Selecciona los puertos como salida
	DDRE |= 0x08; //ServoC pin 3 puerto E
	
	//Inicializa los pines de ADC
	ConfigurarADC();
	UART_init();
	
	//Inicializa PWM
	SERVO_init(5);

	while (1)
	{
		//Lee el potenciometro
		valorPot = leerADC(ADC2, 1); //Lee el puerto A10

		//Calibracion haciendo uso del potenciometro
		servo = valorPot * 0.474;
		servo = servo+110;
		
		//Ejecuta Servo
		set_SERVO(5,servo,0);
	}	
}


