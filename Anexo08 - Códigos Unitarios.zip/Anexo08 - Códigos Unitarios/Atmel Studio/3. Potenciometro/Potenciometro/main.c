/*
 * Potenciometro.c
 *
 * Created: 4/10/2023 7:15:33 p. m.
 * Author : danie
 */ 

#define F_CPU 16000000

#include <avr/io.h>
#include "UART/UART.h"
#include "ADC/ADC.h"
#include <util/delay.h>
#include <stdlib.h>

//Variables
uint16_t lecturaADC = 0;
uint8_t canal;
char buffer [sizeof(unsigned int)*8+1];

int main(void)
{
	UART_init();
	ConfigurarADC();
	
    while (1) 
    {
		lecturaADC = leerADC(ADC2, 1); //Lee el puerto A10
		_delay_ms(100);
		utoa(lecturaADC, buffer, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("El valor es= ");
		UART_write_txt(buffer);
		UART_write_txt("\n\r");
    }
}
