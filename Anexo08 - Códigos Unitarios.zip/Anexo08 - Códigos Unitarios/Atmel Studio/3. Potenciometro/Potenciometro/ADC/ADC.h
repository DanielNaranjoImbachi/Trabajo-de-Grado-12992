﻿/*
 * ADC.h
 *
 * Created: 5/10/2023 6:47:09 p. m.
 *  Author: danie
 */ 


#ifndef ADC_H_
#define ADC_H_

//Mascaras para usar puertos analogicos
#define ADC0 0x00
#define ADC1 0x01
#define ADC2 0x02
#define ADC3 0x03
#define ADC4 0x04
#define ADC5 0x05
#define ADC6 0x06
#define ADC7 0x07

#include <avr/io.h>
#include <stdbool.h>// Booleanos

//Definicion de funciones
void ConfigurarADC();
uint16_t leerADC(uint8_t canal, bool sup);

#endif /* ADC_H_ */