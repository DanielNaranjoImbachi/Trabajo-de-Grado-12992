/*
 * Temperatura.c
 *
 * Created: 24/10/2023 1:22:55 a. m.
 * Author : danie
 */ 

#include <avr/io.h>
#include <stdbool.h> //Para usar Booleanos
#include "UART/UART.h"
#include <stdlib.h> //Para usar utoa

#define LedR 0x02 //Pin 1
#define LedY 0x08 //Pin 3
#define LedG 0x20 //Pin 5
#define LedW 0x10 //Pin 4
#define LedB 0x04 //Pin 2

//Configuración del ADC
void ConfigurarADC()
{
	ADCSRA = 0x00; //Reset al registro
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	ADCSRA |= ((1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0)); // Preescaler = 128
	ADCSRA |= (1 << ADIF); //Limpiar bandera de conversiÃ³n
	ADCSRA |= (1 << ADEN); //Encender el ADC
	ADCSRA |= (1 << ADSC); //Hacer la primera conversion de 25 ciclos
}

//Función para leer el ADC
uint16_t leerADC(uint8_t canal, bool sup)
{
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	if (sup==1)
	{
		ADCSRB |= 0x08;
		}else{
		ADCSRB &= ~(0x08);
	}
	ADMUX |= canal; //Usa la mascara para seleccionar el puerto de lectura
	ADCSRA |= (1 << ADSC); //Inicia la conversion
	while((ADCSRA) & (1 << ADSC));  //Si ya finalizo la conversion
	return(ADC); // Guardar
}

//Variables
uint16_t lecturaTemp = 0;
char buffer [sizeof(unsigned int)*8+1];

//Para definir la FSM
typedef enum{
	R,
	W,
	Y,
	G,
	B
}STATE;
STATE estado = R;


int main(void)
{
	UART_init();
	ConfigurarADC(); //Llama la función para configurar el ADC
	
	DDRC |= LedR; // LedRojo como salida.
	DDRC |= LedW; // LedBlanco como salida.
	DDRC |= LedY; // LedAmarillo como salida
	DDRC |= LedG; // LedVerde como salida.
	DDRC |= LedB; // LedAzul como salida.
	PORTC &= ~(LedR); //Inicializa en 0 el LedRojo
	PORTC &= ~(LedW); //Inicializa en 0 el LedBlanco
	PORTC &= ~(LedY); //Inicializa en 0 el LedAmarillo
	PORTC &= ~(LedG); //Inicializa en 0 el LedVerde
	PORTC &= ~(LedB); //Inicializa en 0 el LedAzul
	
	while (1)
	{
		lecturaTemp = leerADC(0x03, 1); //Lee el puerto A11
		
		utoa(lecturaTemp, buffer, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("La temperatura es= ");
		UART_write_txt(buffer);
		UART_write_txt("\n\r");

		
		switch (estado)
		{
			case R:
			PORTC |= LedR;
			PORTC &= ~(LedW);
			PORTC &= ~(LedY);
			PORTC &= ~(LedG);
			PORTC &= ~(LedB);
			break;
			
			case W:
			PORTC |= LedW;
			PORTC &= ~(LedR);
			PORTC &= ~(LedY);
			PORTC &= ~(LedG);
			PORTC &= ~(LedB);
			break;
			
			case Y:
			PORTC |= LedY;
			PORTC &= ~(LedR);
			PORTC &= ~(LedW);
			PORTC &= ~(LedG);
			PORTC &= ~(LedB);
			break;
			
			case G:
			PORTC |= LedG;
			PORTC &= ~(LedR);
			PORTC &= ~(LedW);
			PORTC &= ~(LedY);
			PORTC &= ~(LedB);
			break;
			
			case B:
			PORTC |= LedB;
			PORTC &= ~(LedR);
			PORTC &= ~(LedW);
			PORTC &= ~(LedY);
			PORTC &= ~(LedG);
			break;
			
			default:
			PORTC &= ~(LedR);
			PORTC &= ~(LedW);
			PORTC &= ~(LedY);
			PORTC &= ~(LedG);
			PORTC &= ~(LedB);
			break;
		}
		
		//Para controlar la FSM
		if ((lecturaTemp>81)&&(lecturaTemp<101)){
			estado=R;
			} else if ((lecturaTemp>61)&&(lecturaTemp<80)) {
			estado=Y;
			} else if ((lecturaTemp>41)&&(lecturaTemp<60)) {
			estado=G;
			} else if ((lecturaTemp>21)&&(lecturaTemp<40)) {
			estado=B;
			} else if ((lecturaTemp>=0)&&(lecturaTemp<20)) {
			estado=W;
		}
		
	}
}

