﻿/*
 * UART.h
 *
 * Created: 5/10/2023 6:49:39 p. m.
 *  Author: danie
 */ 


#ifndef UART_H_
#define UART_H_

#include <avr/io.h>

//Definicion de las funciones
void UART_init();              //funcion para iniciar el USART AVR asincrono, 8 bits, 9600 baudios,
unsigned char UART_read();          //funcion para la recepcion de caracteres
void UART_write(unsigned char);       //funcion para la transmision de caracteres
void UART_write_txt(char*);           //funcion para la transmision de cadenas de caracteres

#endif /* UART_H_ */