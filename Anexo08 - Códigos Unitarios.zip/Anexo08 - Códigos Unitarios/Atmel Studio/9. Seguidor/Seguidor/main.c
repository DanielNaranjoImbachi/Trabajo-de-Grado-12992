/*
 * Seguidor.c
 *
 * Created: 6/11/2023 1:00:41 a. m.
 * Author : danie
 */ 

#include <avr/io.h>
#include <stdbool.h>// Booleanos

//Variables de estado de seguidores
bool seg1 = 1;
bool seg2 = 1;


int main(void)
{
    DDRK &= ~(0x40); //Seguidor como entrada
	DDRK &= ~(0x80); //Seguidor como entrada 
	
	DDRC |= 0x20; //Led Verde como salida
	PORTC &= ~(0x20); //Inicializa en 0
	DDRC |= 0x02; //Led Rojo como salida
	PORTC &= ~(0x02); //Inicializa en 0
    while (1) 
    {
		//Lectura de seguidores
		seg1 = (PINK & seg1);
		seg2 = (PINK & seg2);
		
		if (seg1==0){
			DDRC |= 0x20; //Enciende led Verde
		} else {
			PORTC &= ~(0x20); //Apaga led Verde
		}
		
		if (seg2==0){
			DDRC |= 0x02; //Enciende led Rojo
			} else {
			PORTC &= ~(0x02); //Apaga led Rojo
		}

    }
}

