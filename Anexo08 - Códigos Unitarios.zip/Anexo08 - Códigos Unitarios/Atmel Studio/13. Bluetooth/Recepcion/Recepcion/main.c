/*
 * Recepcion.c
 *
 * Created: 23/10/2023 6:56:54 p. m.
 * Author : danie
 */ 

#include <avr/io.h>

void UART_init()
{
	DDRE |= (1<<1);             //PE1 COMO SALIDA TX0
	DDRE &= ~(1<<0);            //PE0 COMO ENTRADA RX0
	
	//Configuración de registro A:
	UCSR0A = (0<<TXC0)|(0<<U2X0)|(0<<MPCM0);
	//Registro A: se inician los pines de bandera de finalización de envío
	//Se desactiva la opción de duplicar el ratio de transmisión
	//Se desactiva el modo multiprocessor de comunicación
	
	//Configuración del registro B
	UCSR0B = (0<<RXCIE0)|(0<<TXCIE0)|(0<<UDRIE0)|(1<<RXEN0)|(1<<TXEN0)|(0<<UCSZ02)|(0<<RXB80)|(0<<TXB80);
	// RXCIEn desabilita la interrupción RX, TXCIEn desabilita la interrupción TX, UDRIEn desabilita la interrupción de la bandera UDREn, RXENn habilita el receptor USART, TXENn habilita el transmisor USART, los tres últimos se limpian en 0 (UCSZn2, RXB8n, TXB8n).
	
	//Configuración del registro C
	UCSR0C = (0<<UMSEL01)|(0<<UMSEL00)|(0<<UPM01)|(0<<UPM00)|(0<<USBS0)|(1<<UCSZ01)|(1<<UCSZ00)|(0<<UCPOL0);
	//UMSEL 00 corresponde al modo asíncrono de USART, UPM 00 modo paridad deshabilitado, USBSn 0 1bit de parada, UCSZn modo 8bits, UCPOLn transmitir por subida de flanco y recibir por bajada de flanco.
	
	//Selecciona la velocidad
	UBRR0 = 103;// VELOCIDAD 9600B A 16MHz
}

void UART_write(unsigned char caracter){
	while(!(UCSR0A&(1<<5)));    // mientras el registro UDR0 está lleno espera
	UDR0 = caracter; //cuando el registro UDR0 está vacío se envía el caracter.
}

void UART_write_txt(char* cadena){ //cadena de caracteres de tipo char
	while(*cadena !=0x00){ //mientras el último valor de la cadena sea diferente a el caracter nulo
		UART_write(*cadena);	 //transmite los caracteres de cadena
		cadena++; //incrementa la ubicación de los caracteres en cadena para enviar el siguiente caracter de cadena
	}
}

unsigned char UART_read(){
	if(UCSR0A&(1<<7)){      //si el bit7 del registro UCSR0A se ha puesto a 1
		return UDR0;      //devuelve el dato almacenado en el registro UDR0
	}
	else{
		return 0;
	}
}

//Variables
uint8_t leer;

int main(void)
{
    UART_init();
	DDRC |= 0x02; //Led rojo
	PORTC &= ~(0x02); //Inicializa en 0
	
    while (1) 
    {
		if(UCSR0A&(1<<7)){
			leer = UART_read(); //Lee el dato que entra
			char input2 = (char) leer; //Convierte el dato a char
			UART_write(input2); //Muestra el dato
			UART_write_txt("\n\r"); //Salto de línea
		}
		else {
			PORTC |= 0x02; //Enciende Led Rojo
		}
    }
}

