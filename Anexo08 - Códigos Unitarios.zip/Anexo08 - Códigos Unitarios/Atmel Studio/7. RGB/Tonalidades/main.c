/*
 * Tonalidades.c
 *
 * Created: 24/10/2023 2:19:53 a. m.
 * Author : danie
 */ 

#include <avr/io.h>
#include <stdbool.h>// Booleanos
#include "UART/UART.h"
#include <stdlib.h> //Para usar utoa

#define LedR 0x20 //Pin 5
#define LedG 0x40 //Pin 6
#define LedB 0x10 //Pin 4

#define boton1 0x08 //Pin 3
#define boton2 0x20 //Pin 5

//Para definir la FSM
typedef enum{
	R,
	G,
	B
}STATE;
STATE estado = R;

//Configuración del ADC
void ConfigurarADC()
{
	ADCSRA = 0x00; //Reset al registro
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	ADCSRA |= ((1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0)); // Preescaler = 128
	ADCSRA |= (1 << ADIF); //Limpiar bandera de conversión
	ADCSRA |= (1 << ADEN); //Encender el ADC
	ADCSRA |= (1 << ADSC); //Hacer la primera conversión de 25 ciclos
}

//Función para leer el ADC
uint16_t leerADC(uint8_t canal, bool sup)
{
	ADMUX = 0x00; //Reset al registro
	ADMUX |= 0x40;// Selecciona AVCC como referencia
	ADMUX &= ~(1<<ADLAR); //Desactiva el ADLAR
	if (sup==1)
	{
		ADCSRB |= 0x08;
		}else{
		ADCSRB &= ~(0x08);
	}
	ADMUX |= canal; //Usa la mascara para seleccionar el puerto de lectura
	ADCSRA |= (1 << ADSC); //Inicia la conversion
	while((ADCSRA) & (1 << ADSC));  //Si ya finalizo la conversion
	return(ADC); // Guardar
}

//Variables
uint16_t lecturaADC = 0;
bool btn1 = 1;
bool btn2 = 1;
uint16_t valor = 0;
uint16_t dcR = 0;
uint16_t dcG = 0;
uint16_t dcB = 0;

char bufferR [sizeof(unsigned int)*8+1];
char bufferG [sizeof(unsigned int)*8+1];
char bufferB [sizeof(unsigned int)*8+1];


int main(void)
{
	DDRG |= LedR; // Led Rojo como salida.
	DDRH |= LedG; // Led Verde como salida
	DDRB |= LedB; // Led Azul como salida.
	
	//Declaración de pines de entrada
	DDRA &= ~(boton1); //El pin 3 del puerto A se declara como entrada // Boton1 PIN 25
	PORTA |= boton1; //Asigna como pullup el boton1
	DDRA &= ~(boton2); //El pin 5 del puerto A se declara como entrada // Boton2 PIN 27
	PORTA |= boton2; //Asigna como pullup el boton2
	
	//Configuración PWM usando Timer0
	TCCR0B &= ~(0x08); //Registro WGM02
	TCCR0A |= 0x03; //Registros WGM01 y WGM00
	TCCR0B |= 0x05; //Preescaler de 1024
	TCCR0A |= 0x20; //Modo no invertido PWM B //pin4
	
	//Configuración PWM usando Timer2
	TCCR2B &= ~(0x08); //Registro WGM22
	TCCR2A |= 0x03; //Registros WGM21 y WGM20
	TCCR2B |= 0x07; //Preescaler de 1024
	TCCR2A |= 0x20; //Modo no invertido PWM B //pin9
	TCCR2A |= 0x80; //Modo no invertido PWM A //pin10
	
	UART_init();
	ConfigurarADC(); //Llama la función para configurar el ADC

	while (1)
	{
		//Lectura de botones
		btn1 = (PINA & boton1);
		btn2 = (PINA & boton2);
		
		valor = leerADC(0x02, 1); //Lee el puerto A10
		
		switch (estado)
		{
			case R:
				if(btn1 == 0) {
					estado=B;
					}else {
					estado=R;
				}
				if(btn2 == 0) {
					estado=G;
					}else {
					estado=R;
				}
				//Calcula PWM
				dcR = valor * 0.25;
				OCR0B = dcR; //Ajusta led Rojo
			break;
			
			case G:
				if(btn1 == 0) {
					estado=R;
					}else {
					estado=G;
				}
				if(btn2 == 0) {
					estado=B;
					}else {
					estado=G;
				}
				//Calcula PWM
				dcG = valor * 0.25;
				OCR2B = dcG; //Enciende led Verde
			break;
			
			case B:
				if(btn1 == 0) {
					estado=G;
					}else {
					estado=B;
				}
				if(btn2 == 0) {
					estado=R;
					}else {
					estado=B;
				}
				//Calcula PWM
				dcB = valor * 0.25;
				OCR2A = dcB; //Enciende led Azul
			break;
			
			default:
			PORTG &= ~(LedR); //Apaga por default
			PORTB &= ~(LedG); //Apaga por default
			PORTB &= ~(LedB); //Apaga por default
			break;
		}
		
		utoa(dcR, bufferR, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("Rojo= ");
		UART_write_txt(bufferR);
		utoa(dcG, bufferG, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("  Verde= ");
		UART_write_txt(bufferG);
		utoa(dcB, bufferB, 10); //Convierte el valor en cadena de caracteres
		UART_write_txt("  Azul= ");
		UART_write_txt(bufferB);
		UART_write_txt("\n\r");
	}
}


