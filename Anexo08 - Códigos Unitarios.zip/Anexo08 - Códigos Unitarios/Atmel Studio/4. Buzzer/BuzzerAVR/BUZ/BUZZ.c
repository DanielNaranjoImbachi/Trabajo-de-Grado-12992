﻿/*
 * BUZ.c
 *
 * Created: 10/10/2023 1:54:07 a. m.
 *  Author: danie
 */ 

#include "BUZZ.h"

void my_delay_ms(int ms)
{
	while (0 < ms)
	{
		_delay_ms(1);
		--ms;
	}
}

void set_tone(uint8_t pin, uint16_t freq, int duracion)
{
	switch (pin)
	{
		case 2:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR3B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR3A |= 0x02; //Registros WGMn1 y WGMn0
		//--##### Ajusta el modo no invertido #####--
		TCCR3A |= 0x20;
		//--##### Selecciona el prescaler de 1 #####--
		TCCR3B |= 0x01;
		
		//--##### Se ajusta el oscilador #####--
		ICR3 = 16000000/freq;
		ICR3 = ICR1 - 1;
		OCR3B = ICR3/2;
		my_delay_ms(duracion);
		OCR3B = 0;
		break;
		
		case 3:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR3B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR3A |= 0x02; //Registros WGMn1 y WGMn0
		//--##### Ajusta el modo no invertido #####--
		TCCR3A |= 0x08;
		//---##### Selecciona el prescalador Timer 3 #####--
		TCCR3B |= 0x01; //Preescaler de 1
		
		//--##### Se ajusta el oscilador #####--
		ICR3 = 16000000/freq;
		ICR3 = ICR3 - 1;
		OCR3C = ICR3/2;
		my_delay_ms(duracion);
		OCR3C = 0;
		break;
		
		case 5:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR3B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR3A |= 0x02; //Registros WGMn1 y WGMn0
		//--##### Ajusta el modo no invertido #####--
		TCCR3A |= 0x80;
		//---##### Selecciona el prescalador Timer 3 #####--
		TCCR3B |= 0x01; //Preescaler de 1
		
		//--##### Se ajusta el oscilador #####--
		ICR3 = 16000000/freq;
		ICR3 = ICR3 - 1;
		OCR3A = ICR3/2;
		my_delay_ms(duracion);
		OCR3A = 0;
		break;
		
		case 6:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR4B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR4A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 4 #####--
		TCCR4B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR4A |= 0x80;
		
		//--##### Se ajusta el oscilador #####--
		ICR4 = 16000000/freq;
		ICR4 = ICR4 - 1;
		OCR4A = ICR4/2;
		my_delay_ms(duracion);
		OCR4A = 0;
		break;
		
		case 7:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR4B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR4A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 4 #####--
		TCCR4B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR4A |= 0x20;
		
		//--##### Se ajusta el oscilador #####--
		ICR4 = 16000000/freq;
		ICR4 = ICR4 - 1;
		OCR4B = ICR4/2;
		my_delay_ms(duracion);
		OCR4B = 0;
		break;
		
		case 8:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR4B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR4A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 4 #####--
		TCCR4B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR4A |= 0x08;

		//--##### Se ajusta el oscilador #####--
		ICR4 = 16000000/freq;
		ICR4 = ICR4 - 1;
		OCR4C = ICR4/2;
		my_delay_ms(duracion);
		OCR4C = 0;
		break;
		
		case 11:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR1B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR1A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 1 #####--
		TCCR1B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR1A |= 0x80;
		
		//--##### Se ajusta el oscilador #####--
		ICR1 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR1 = ICR1 - 1;
		OCR1A = ICR1/2;
		my_delay_ms(duracion);
		OCR1A = 0;
		break;
		
		case 12:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR1B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR1A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 1 #####--
		TCCR1B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR1A |= 0x20;
		
		//--##### Se ajusta el oscilador #####--
		ICR1 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR1 = ICR1 - 1;
		OCR1B = ICR1/2;
		my_delay_ms(duracion);
		OCR1B = 0;
		break;
		
		case 13:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR1B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR1A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 1 #####--
		TCCR1B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR1A |= 0x08;

		//--##### Se ajusta el oscilador #####--
		ICR1 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR1 = ICR1 - 1;
		OCR1C = ICR1/2;
		my_delay_ms(duracion);
		OCR1C = 0;
		break;
		
		case 44:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR5B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR5A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 5 #####--
		TCCR5B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR5A |= 0x08;
		
		//--##### Se ajusta el oscilador #####--
		ICR5 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR5 = ICR5 - 1;
		OCR5C = ICR5/2;
		my_delay_ms(duracion);
		OCR5C = 0;
		break;
		
		case 45:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR5B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR5A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 5 #####--
		TCCR5B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR5A |= 0x20;
		
		//--##### Se ajusta el oscilador #####--
		ICR5 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR5 = ICR5 - 1;
		OCR5B = ICR5/2;
		my_delay_ms(duracion);
		OCR5B = 0;
		break;
		
		case 46:
		//--##### Ajusta el modo FAST PWM con top en ICRn #####--
		TCCR5B |= 0x18; //Registros WGMn3 y WGMn2
		TCCR5A |= 0x02; //Registros WGMn1 y WGMn0
		//---##### Selecciona el prescalador Timer 5 #####--
		TCCR5B |= 0x01; //Preescaler de 1
		//--##### Ajusta el modo no invertido #####--
		TCCR5A |= 0x80;
		
		//--##### Se ajusta el oscilador #####--
		ICR5 = 16000000/freq; //Para usar el Buzzer con prescaler de 1
		ICR5 = ICR5 - 1;
		OCR5A = ICR5/2;
		my_delay_ms(duracion);
		OCR5A = 0;
		break;
		
		default:
		
		break;
	}
}