﻿/*
 * BUZZ.h
 *
 * Created: 10/10/2023 1:53:50 a. m.
 *  Author: danie
 */ 

#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>

#ifndef BUZZ_H_
#define BUZZ_H_

void my_delay_ms(int ms);
void set_tone(uint8_t pin, uint16_t freq, int duracion);

#endif /* BUZZ_H_ */