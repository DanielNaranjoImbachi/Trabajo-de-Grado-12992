/*
 * BuzzerAVR.c
 *
 * Created: 10/10/2023 1:52:32 a. m.
 * Author : danie
 */ 

#define F_CPU 16000000

#include <avr/io.h>
#include "BUZ/BUZZ.h"
#include <util/delay.h>

int main(void)
{
    DDRB |= 0x40; //Buzzer Pin 6 Puerto B
    while (1) 
    {
		set_tone(12, 1000, 1000);
		set_tone(12, 500, 1000);
		_delay_ms(5000);
    }
}

