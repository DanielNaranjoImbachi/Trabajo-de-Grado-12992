/*
 * Botones.c
 *
 * Created: 4/10/2023 3:03:13 p. m.
 * Author : danie
 */ 

//Mascaras para los pines
#define boton1 0x08
#define boton2 0x20
#define ledR 0x02
#define ledV 0x20

#define F_CPU 16000000
#include <avr/io.h>
#include <stdbool.h>// Booleanos
#include <util/delay.h>

//Variables de estado de botones y leds
bool btn1 = 1;
bool btn2 = 1;

int main(void)
{
	//Declaracion de pines de entrada
	DDRA &= ~(boton1); //El pin 3 del puerto A se declara como entrada // Boton1 PIN 25
	PORTA |= boton1; //Asigna como pullup el boton1
	DDRA &= ~(boton2); //El pin 5 del puerto A se declara como entrada // Boton2 PIN 27
	PORTA |= boton2; //Asigna como pullup el boton2
	//Declaracion de pines de salida
	DDRC |= ledR; // El pin 1 del puerto C se define como salida / Led Rojo PIN 36
	PORTC &= ~(ledR); //Inicializa en 0 el Led rojo
	DDRC |= ledV; // El pin 5 del puerto A se define como salida / Led Verde PIN 32
	PORTC &= ~(ledV); // Inicializa en 0 el Led verde
	
	while (1)
	{
		//Lectura de botones
		btn1 = (PINA & boton1);
		btn2 = (PINA & boton2);
		
		//Si se presiona el boton 1
		if(btn1 == 0) { 
			_delay_ms(100);
			if(btn1 == 0) { //Para el antirrrebote vuelve a preguntar
				if((PORTC & ledR)==1){ //Si el led rojo esta encendido
					PORTC &= ~(ledR); //Apaga el led rojo
				} else{
					PORTC |= ledR; //Enciende el led rojo
				}
			} else{
				if((PORTC & ledR)==1){ //Si el led rojo esta encendido
					PORTC |= ledR; //Permanece encendido
					} else{
					PORTC &= ~(ledR); //Permanece apagado
					}
			}
		} else{
			if((PORTC & ledR)==1){ //Si el led rojo esta encendido
				PORTC |= ledR; //Permanece encendido
			} else{
				PORTC &= ~(ledR); //Permanece apagado
			}
		}
		
		//Si se presiona el boton 2
		if(btn2 == 0) {
			_delay_ms(100);
			if(btn2 == 0) { //Para el antirrrebote vuelve a preguntar
				if((PORTC & ledV)==1){ //Si el led verde esta encendido
					PORTC &= ~(ledV); //Apaga el led verde
				} else{
					PORTC |= ledV; //Enciende el led rojo
				}
			} else{
				if((PORTC & ledV)==1){ //Si el led verde esta encendido
					PORTC |= ledV; //Permanece encendido
				} else{
					PORTC &= ~(ledV); //Permanece apagado
				}
			} 
		}else{
				if((PORTC & ledV)==1){ //Si el led verde esta encendido
					PORTC |= ledV; //Permanece encendido
				} else{
					PORTC &= ~(ledV); //Permanece apagado
				}
		}
	} // While
} // Main
